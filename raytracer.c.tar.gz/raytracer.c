#include "raytracer.h"
#include "globals.h"
#include "utils.h"

#include <math.h>

void degrade(ray r,int i, int j)
{
  vec3 color;
  color.x = ((i+0.5-WIDTH/2)*0.5)/(WIDTH/2) + 0.5;
  color.y = ((j+0.5-HEIGHT/2)*0.5)/(HEIGHT/2) + 0.5;
  color.z = 0;

  output_image[i + j*WIDTH] = color;
}

double equat_plan(ray r, object plan){
    return -((vector_dot(plan.normal,r.orig) + plan.dist)/vector_dot(r.dir,plan.normal));
}

//t^2(d~.d~) + 2t(d~.(o − c)) + ((o − c).(o − c) − r^2) = 0

double equat_cercl(ray r, object sphere){
  double a = vector_dot(r.dir,r.dir);
  double b = 2.0f*(vector_dot(r.dir, vector_minus(r.orig, sphere.center)));
  double c = vector_dot(vector_minus( r.orig, sphere.center),vector_minus( r.orig, sphere.center)) - pow(sphere.radius,2);
  double delta = pow(b,2) - 4*a*c;
  double t1,t2;
  if (delta > 0) {
    t1 = (-b - sqrt(delta))/(2*a);
    t2 = (-b + sqrt(delta))/(2*a);
    if (((t1 < r.tmin) && (t2 < r.tmin)) || ((t1 > r.tmax) && (t1 > r.tmax))) { //t1 et t2 pas dans intervalle
      return -1;
    } else {
      if ((t1 > r.tmax) || (t1 < r.tmin)) { //t1 pas dans intervalle
         return t2;
      } else if ((t2 > r.tmax) || (t2 < r.tmin)) {  //t2 pas dans intervalle
          return t1;
      } else {
        if (t1 > t2) {
          return t2;
        } else {
          return t1;
        }
      }
    }
  } else if (delta == 0 ) {
    t1 = -b /(2*a);
    if ((t1 < r.tmin) || (t1 > r.tmax)){
      return -1;
    } else {
      return t1;
    }
  } else {
    return -1;
  }
}

float intersect(ray rayon, int idobjet)
{
  object monobjet = scene[idobjet];
  if(monobjet.type == PLANE)
    return equat_plan(rayon, monobjet);
  else if(monobjet.type == SPHERE)
    return equat_cercl(rayon, monobjet);
  else return 0.0f;
}

inline color scaltest(ray rayon) {
        // retourne le scalaire entre la caméra et l'écran
        vec3 color;
        color.x = powf(vector_dot(rayon.dir,theCamera.zdir), 10.0f);
        color.y = color.x;
        color.z = color.x;

        return color;
}

color trace_ray(ray rayon){

  float t;
  float tmin = rayon.tmax;
  int idobjet = 0;
  int idobjetmin;
  for (int i = 0; i < object_count; ++i){
    t = intersect(rayon, i); 
    if(t>0 && t<tmin) {
      idobjetmin = i;
      tmin = t; 
   }
  }
  if (tmin == rayon.tmax) {
    return vector_init(0.2,0.2,0.6);
  } else {
    return scene[idobjetmin].mat.kd;
  }
}

void raytrace(){
  int i,j;
   
  float width_2 = WIDTH * 0.5f;
  float height_2 = HEIGHT * 0.5f;
  float inv_width_2 = 1.0f / width_2;
  float inv_height_2 = 1.0f / height_2;
  
  ray r;
  vec3 dir;
  float cfov = 0.5f * theCamera.fov;
  float res_tan = 1.0f / tan(cfov);

  vec3 xr = theCamera.xdir;
  vec3 yr = vector_float_mul((WIDTH/HEIGHT),theCamera.ydir);
  vec3 zr = theCamera.center;
  for (i = 0; i < WIDTH; i++)
  {
    for (j = 0; j < HEIGHT; j++)
    {  
      dir = vector_add(vector_add(vector_float_mul((i+.5-WIDTH/2)/(WIDTH/2),xr),vector_float_mul((j+0.5-HEIGHT/2)/(HEIGHT/2),yr)),zr);
      ray_init(&r,theCamera.center,dir);
      output_image[j*WIDTH+i] = trace_ray(r);
    }
  }
}

